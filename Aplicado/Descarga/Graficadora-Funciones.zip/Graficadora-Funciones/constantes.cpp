//Constantes
const int ancho = 1000; //A
const int alto = 720;  //B
const int k = 10;
