# Graficadora en C++
Graficadora hecha en c++ utilizando algunas funciones de la librería de graphics.h y winbgim
